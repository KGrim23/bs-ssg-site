# This is the course work Git Workflow:
Here is the working netlify link.


https://bs-ssg-site.netlify.app


